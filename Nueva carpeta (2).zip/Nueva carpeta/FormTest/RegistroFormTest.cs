using Bunit;
using Xunit;
using blazor.Pages;

namespace FormTest.Tests
{
    public class RegistroFormTest : TestContext
    {
        [Fact]
        public void Debe_Mostrar_Mensaje_Usuario_Registrado()
        {
            // Arrange
            var component = RenderComponent<Formulario>();

            // Act
            component.Find("#nombre").Change("María");
            component.Find("#correo").Change("maria@example.com");
            component.Find("#password").Change("12345");
            component.Find("#btnRegistrar").Click();

            // Assert
            var mensaje = component.Find("div.alert").TextContent;
            Assert.Equal("Usuario registrado correctamente", mensaje);
        }
    }
}
